var gulp			   = require('gulp'),
		sass           = require('gulp-sass'),
		browserSync    = require('browser-sync'),
		concat         = require('gulp-concat'),
		uglify         = require('gulp-uglify'),
		cleanCSS       = require('gulp-clean-css'),
		rename         = require('gulp-rename'),
		autoprefixer   = require('gulp-autoprefixer'),
		bourbon        = require('node-bourbon'),
		notify         = require("gulp-notify"),
		sourcemaps 	   = require('gulp-sourcemaps'),
		minify		   = require('gulp-minify'),
		dir_theme 	   = "wp-content/themes/style";


gulp.task('browser-sync', function() {
	browserSync({
		proxy: "style.loc",
		notify: false,
		browser: "chrome"
	});
});

gulp.task('sass', function() {
	return gulp.src(dir_theme + '/sass/**/*.scss')
		.pipe(sourcemaps.init())
		.pipe(sass({
			includePaths: bourbon.includePaths
		}).on("error", notify.onError()))
		.pipe(sourcemaps.write())
		.pipe(rename({suffix: '.min', prefix : ''}))
		.pipe(autoprefixer(['last 15 versions']))
		.pipe(cleanCSS())
		.pipe(minify())
		.pipe(gulp.dest(dir_theme + '/css/'))
		.pipe(browserSync.reload({stream: true}))
});

gulp.task('headersass', function() {
	return gulp.src(dir_theme + '/sass/header.scss')
		.pipe(sourcemaps.init())
		.pipe(sass({
			includePaths: bourbon.includePaths
		}).on("error", notify.onError()))
		.pipe(sourcemaps.write())
		.pipe(rename({suffix: '.min', prefix : ''}))
		.pipe(autoprefixer(['last 15 versions']))
		.pipe(cleanCSS())
		.pipe(minify())
		.pipe(gulp.dest(dir_theme + '/css'))
		.pipe(browserSync.reload({stream: true}))
});

gulp.task('js', function() {
	return gulp.src([
		dir_theme + '/js/common.js',
	])
        .pipe(concat('common.min.js'))
		.pipe(uglify())
		.pipe(gulp.dest(dir_theme + '/js'))
		.pipe(browserSync.reload({stream: true}));
});

gulp.task('libs', function() {
	return gulp.src([
			dir_theme + '/libs/jquery/jquery.min.js',
			dir_theme + '/libs/slick/slick.min.js',
			dir_theme + '/libs/magnific-popup/dist/jquery.magnific-popup.min.js',
		])
		.pipe(concat('libs.min.js'))
		// .pipe(minify())
		.pipe(uglify())
		.pipe(gulp.dest(dir_theme + '/js'));
});

gulp.task('watch', ['sass', 'js', 'browser-sync'], function() {
	gulp.watch(dir_theme + '/**/*.php', browserSync.reload);
	gulp.watch(dir_theme + '/sass/header.scss', ['headersass']);
	gulp.watch(dir_theme + '/sass/**/*.scss', ['sass']);
	gulp.watch(dir_theme + '/js/**/*.js', ['js']);
});

gulp.task('default', ['watch']);